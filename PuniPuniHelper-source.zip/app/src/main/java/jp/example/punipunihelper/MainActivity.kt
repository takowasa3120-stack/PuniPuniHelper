package jp.example.punipunihelper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("helper", Context.MODE_PRIVATE) }
    private lateinit var interval: EditText
    private lateinit var xCoord: EditText
    private lateinit var yCoord: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "ぷにぷに操作補助"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "単純な自動タップ用の試作版です。ゲーム内の数値変更・倍速・無敵機能はありません。"
            textSize = 15f
            setPadding(0, 12, 0, 16)
        })
        layout.addView(label("タップ間隔（ミリ秒）"))
        interval = field(prefs.getInt("interval", 800).toString())
        layout.addView(interval)
        layout.addView(label("X座標（画面左から）"))
        xCoord = field(prefs.getInt("x", 500).toString())
        layout.addView(xCoord)
        layout.addView(label("Y座標（画面上から）"))
        yCoord = field(prefs.getInt("y", 900).toString())
        layout.addView(yCoord)
        layout.addView(button("設定を保存") { saveSettings() })
        layout.addView(button("ユーザー補助設定を開く") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("自動タップ開始") {
            saveSettings()
            prefs.edit().putBoolean("running", true).apply()
            Toast.makeText(this, "自動タップを開始しました（サービスの有効化が必要）", Toast.LENGTH_LONG).show()
        })
        layout.addView(button("自動タップ停止") {
            prefs.edit().putBoolean("running", false).apply()
            Toast.makeText(this, "自動タップを停止しました", Toast.LENGTH_SHORT).show()
        })
        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 18, 0, 0)
        }
        layout.addView(status)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            status.text = if (prefs.getBoolean("running", false)) "状態：開始フラグ ON" else "状態：停止中"
        }
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setPadding(0, 8, 0, 0)
    }

    private fun field(value: String): EditText = EditText(this).apply {
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setSingleLine(true)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 8 }
    }

    private fun saveSettings() {
        val ms = interval.text.toString().toIntOrNull()?.coerceIn(100, 60000) ?: 800
        val x = xCoord.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 500
        val y = yCoord.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 900
        prefs.edit().putInt("interval", ms).putInt("x", x).putInt("y", y).apply()
        Toast.makeText(this, "設定を保存しました", Toast.LENGTH_SHORT).show()
    }
}
