package jp.example.punipunihelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastTapAt = 0L

    private val loop = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("helper", MODE_PRIVATE)
            if (!prefs.getBoolean("running", false)) {
                handler.postDelayed(this, 250)
                return
            }
            val interval = prefs.getInt("interval", 800).coerceIn(100, 60000)
            val now = System.currentTimeMillis()
            if (now - lastTapAt >= interval) {
                val x = prefs.getInt("x", 500).toFloat().coerceAtLeast(0f)
                val y = prefs.getInt("y", 900).toFloat().coerceAtLeast(0f)
                val path = Path().apply { moveTo(x, y) }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
                    .build()
                dispatchGesture(gesture, null, null)
                lastTapAt = now
            }
            handler.postDelayed(this, 50)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        getSharedPreferences("helper", MODE_PRIVATE).edit().putBoolean("running", false).apply()
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
